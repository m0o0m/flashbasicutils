DROP TABLE IF EXISTS `muppets`;
CREATE TABLE `muppets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `pword` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `muppets`
-- 

INSERT INTO `muppets` (`id`, `name`, `pword`, `email`) VALUES (1, 'Kermit', 'thefrog', 'kermit@muppets.net');
INSERT INTO `muppets` (`id`, `name`, `pword`, `email`) VALUES (2, 'Gonzo', 'thegreat', 'gonzo@muppets.net');
INSERT INTO `muppets` (`id`, `name`, `pword`, `email`) VALUES (3, 'Fozzie', 'bear', 'fozzie@muppets.net');
INSERT INTO `muppets` (`id`, `name`, `pword`, `email`) VALUES (4, 'Piggy', 'thepig', 'piggy@muppets.net');
